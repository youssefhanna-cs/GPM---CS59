# دليل تدفق تطبيق GPM (GPM Application Flow Guide)

يحتوي هذا الملف على ثلاثة أقسام رئيسية تلبيةً لطلبك:
1. **البرومبت التفصيلي (Detailed Prompt)**: برومبت احترافي يمكن استخدامه مع الذكاء الاصطناعي لتوليد تدفق التطبيق لأي نظام مشابه.
2. **تدفق التطبيق بالتفصيل (Detailed Application Flow)**: التدفق الفعلي الكامل لمنصة GPM بناءً على الأدوار والحالات المختلفة (مع ربطها بالـ API Endpoints الخاصة بالمشروع).
3. **مخططات تدفق التطبيق المنظمة (Organized Diagrams)**: مخططات توضيحية باستخدام صيغة Mermaid (مخطط الحالات State Machine ومخطط التدفق العام Flowchart).

---

## 1. البرومبت التفصيلي لاستخراج تدفق التطبيق (Detailed Prompt)

يمكنك استخدام هذا البرومبت (Prompt) مع نماذج الذكاء الاصطناعي (مثل Gemini أو ChatGPT) لتحليل أي ملفات توثيق أو أكواد برمجية واستخراج تدفق التطبيق منها بدقة:

```text
أنت مهندس برمجيات ومصمم تجربة مستخدم (UX Architect) خبير. أريد منك تحليل الكود البرمجي وملفات التوثيق الخاصة بمشروعنا (منصة إدارة مشاريع التخرج - GPM) وإنشاء وثيقة "تدفق التطبيق" (Application Flow) شاملة ودقيقة.

لتحقيق ذلك، يرجى اتباع الإرشادات التالية في التحليل:
1. تحديد أدوار المستخدمين (Actors): (مثلاً: طالب بدون فكرة، صاحب فكرة، عضو فريق، مشرف، مساعد تدريس TA، مسؤول النظام Admin).
2. تتبع رحلة المستخدم (User Journeys):
   - تدفق المصادقة والتحقق (Authentication & Onboarding).
   - رحلة الطالب وتغير حالاته (Student States): من مرحلة "بدون فكرة" إلى "إنشاء أو انضمام لفكرة"، ثم "فحص التشابه بالذكاء الاصطناعي"، ثم "تقديم الطلب للمشرف"، ثم "المشروع النشط وإدارة المهام والاجتماعات"، وصولاً إلى "رصد الدرجات النهائية والأرشفة".
   - رحلة المشرف ومساعد التدريس (Supervisor/TA Flow): مراجعة طلبات الإشراف، إدارة المشاريع، جدولة الاجتماعات، ورصد درجات المناقشات الثلاث.
3. ربط الشاشات بالعمليات الخلفية (API Endpoints): تحديد الـ API المستخدم في كل خطوة أو انتقال بين الحالات (مثل: /login، /ideas/join-requests، /ai-check، إلخ).
4. تحديد الشروط والانتقالات (State Transitions & Rules): ما هي الشروط اللازمة للانتقال من حالة إلى أخرى (مثلاً: لا يمكن تشغيل فحص AI إلا بعد اكتمال الفريق، لا يمكن تعديل الفكرة بعد التقديم للمشرف).

قم بصياغة النتيجة في شكل دليل منظم يحتوي على تفصيل لكل خطوة، متبوعاً بمخططات Mermaid.js واضحة تمثل الحالات (State Machine) والتدفق العام (Flowchart).
```

---

## 2. تدفق التطبيق التفصيلي (GPM Application Flow)

يعتمد تطبيق GPM على نظام **الحالات الديناميكية (State-Driven Architecture)** لتحديد ما يظهر للطلبة والمشرفين بناءً على حالة المشروع الحالية في قاعدة البيانات.

### أولاً: تدفق الدخول والمصادقة (Authentication & Onboarding Flow)
1. **شاشة الترحيب (Welcome Screen)**:
   - تتيح للمستخدم الاختيار بين تسجيل الدخول (Login) أو إنشاء حساب جديد (Register).
2. **تسجيل الدخول (Login Flow)**:
   - يقوم المستخدم بإدخال البريد الأكاديمي وكلمة المرور.
   - يستدعي التطبيق الـ API: `POST /login`.
   - عند النجاح: يتم حفظ الـ JWT Token وتوجيه المستخدم للوحة التحكم (Dashboard) الخاصة بدوره (`role`):
     - **student** -> لوحة تحكم الطالب.
     - **supervisor / teachingAssistant** -> لوحة تحكم المشرف/المعيد.
     - **admin** -> لوحة تحكم المسؤول.
3. **إنشاء حساب جديد (Register Flow)**:
   - يدخل المستخدم بياناته (الاسم، البريد الأكاديمي، كلمة المرور، الهاتف، التخصص العلمي، الدور، الصورة الشخصية).
   - يستدعي التطبيق الـ API: `POST /signup` (بصيغة `multipart/form-data`).
   - عند النجاح: يتم التوجيه لشاشة تسجيل الدخول.
4. **استعادة كلمة المرور (Forgot Password)**:
   - إدخال البريد الأكاديمي -> استدعاء `POST /auth/forgot-password`.
   - إرسال كود التحقق للبريد -> إدخال الكود وتعيين كلمة المرور الجديدة -> استدعاء `POST /auth/reset-password`.

---

### ثانياً: تدفق رحلة الطالب وحالاته (Student Journey & Transitions)

يمر الطالب في النظام بـ **6 حالات أساسية**، وتتغير الواجهة والصلاحيات ديناميكياً بناءً عليها:

#### الحالة 1: بدون فكرة (No Idea)
* **الهدف**: الانضمام لفريق أو ابتكار فكرة جديدة.
* **التدفق والشاشات**:
  1. **لوحة التحكم (Dashboard)**: تعرض بطاقات سريعة للوصول إلى "سوق الأفكار" أو "إنشاء فكرة".
  2. **سوق الأفكار (Ideas Marketplace)**:
     - تصفح الأفكار المتاحة للطلاب الآخرين (`GET /ideas`).
     - إمكانية الإعجاب بالفكرة (`POST /ideas/{ideaId}/like`) أو التعليق عليها (`POST /ideas/{ideaId}/comments`).
     - إرسال طلب انضمام لفريق الفكرة -> استدعاء `POST /ideas/{ideaId}/join-requests`.
  3. **البحث عن زملائه (Team Finder)**: تصفح الطلاب الآخرين المتاحين ومهاراتهم للتواصل وتشكيل الفرق.
  4. **إنشاء فكرة جديدة (Create Idea)**:
     - تعبئة نموذج الفكرة (العنوان، الوصف، المهارات المطلوبة، الحد الأقصى لأعضاء الفريق).
     - استدعاء الـ API: `POST /ideas` -> ينتقل الطالب تلقائياً ليصبح **صاحب فكرة (Idea Owner)**.

#### الحالة 2: صاحب فكرة (Idea Owner)
* **الهدف**: تجميع الفريق وتجهيز المشروع للمراجعة الرسمية.
* **التدفق والشاشات**:
  1. **لوحة التحكم**: تعرض تفاصيل فكرته الخاصة وقسم "طلبات الانضمام المعلقة" (`Join Requests`).
  2. **إدارة طلبات الانضمام**:
     - مراجعة الطلاب المتقدمين وقبولهم (`POST /ideas/{ideaId}/join-requests/accept`) أو رفضهم (`POST /ideas/{ideaId}/join-requests/reject`).
     - إمكانية تعديل بيانات الفكرة (`PUT /ideas/{ideaId}`) ما دامت لم تُرسل للمشرف بعد.
  3. **شرط فحص التشابه (AI Check)**:
     - عند اكتمال عدد أعضاء الفريق المطلوب، يظهر زر **Run AI Check**.
     - يستدعي الـ API: `POST /ideas/{ideaId}/ai-check` لفحص نسبة التشابه بالذكاء الاصطناعي لضمان عدم التكرار.
     - إذا نجح الفحص (نسبة التشابه أقل من 30%): يتم تفعيل خيار تقديم الطلب للمشرف.
  4. **التقديم للمشرف (Submit to Supervisor)**:
     - يختار الطالب المشرف (الدكتور) والمعيد المساعد.
     - يستدعي الـ API: `POST /ideas/{ideaId}/supervisor-request` و `POST /ideas/{ideaId}/ta-request`.
     - تتحول حالة الطالب والفكرة إلى **تحت المراجعة (Under Review)**.

#### الحالة 3: عضو في فكرة (Idea Member)
* **الهدف**: شريك في الفريق ولكن بصلاحيات محدودة لمنع التضارب.
* **التدفق والشاشات**:
  1. **لوحة التحكم**: تعرض بيانات الفكرة الحالية بصيغة القراءة فقط (Read-only).
  2. **الصلاحيات المحجوبة**: لا يمكنه تعديل الفكرة، ولا تظهر له طلبات الانضمام الخاصة بالآخرين، ولا يمكنه تشغيل فحص AI أو تقديم الطلب للمشرف.
  3. **مغادرة الفريق (Leave Team)**: يمكنه الخروج من الفريق عبر استدعاء `POST /ideas/{ideaId}/leave-team` -> يعود مباشرة لحالة **بدون فكرة (No Idea)**.

#### الحالة 4: فكرة تحت المراجعة (Idea Under Review)
* **الهدف**: انتظار قرار المشرف الأكاديمي.
* **التدفق والشاشات**:
  1. **لوحة التحكم**: تعرض بطاقة الفكرة بحالة "Submitted" مع تجميد كافة العمليات (لا يمكن التعديل أو المغادرة).
  2. **قرار المشرف**:
     - **في حال الرفض**: يصله إشعار وسبب الرفض -> يعود الطالب لحالة **صاحب فكرة** لتعديلها أو اختيار مشرف آخر.
     - **في حال القبول**: يصله إشعار بالقبول وتفعيل المشروع -> ينتقل جميع أعضاء الفريق لحالة **مشروع نشط (Active Project)**.

#### الحالة 5: مشروع نشط (Active Project)
* **الهدف**: مرحلة العمل الفعلي وتنفيذ المهام وحضور الاجتماعات.
* **التدفق والشاشات**:
  1. **لوحة تحكم المشروع النشط**: تعرض شريط تقدم الإنجاز العام (`progress`) والمهام المسندة والاجتماعات المجدولة.
  2. **إدارة المهام (Tasks)**:
     - تصفح المهام الخاصة بالطالب (`GET /student/tasks/{userId}`).
     - تحديث حالة المهمة لـ "قيد العمل" -> `PUT /tasks/{taskId}/status`.
     - تسليم المهمة (رابط الكود/المستندات أو ملف PDF) -> استدعاء `POST /tasks/{taskId}/submit`.
  3. **جدولة ومتابعة الاجتماعات**:
     - تصفح مواعيد الاجتماعات التي يحددها الدكتور أو المعيد (`GET /meetings?projectId=...`).
     - حضور الاجتماعات (أونلاين عبر Google Meet أو أوفلاين في الكلية).
  4. **التقييم والمناقشات**:
     - حضور المناقشة الأولى (الفكرة والتصميم) واستلام الملاحظات والتعديلات المطلوبة.
     - حضور المناقشة الثانية (التقييم الفعلي للبرمجة والإنجاز).

#### الحالة 6: مشروع مكتمل (Project Completed)
* **الهدف**: استعراض التقييم النهائي والتخرج.
* **التدفق والشاشات**:
  1. **لوحة التحكم**: تعرض الدرجة النهائية للمشروع وتفاصيل درجات المناقشة الثالثة والأخيرة (التقرير، العرض، الجانب العملي).
  2. **الأرشفة التلقائية**: يقوم النظام تلقائياً بتحويل ملفات المشروع والمخرجات إلى المكتبة الرقمية العامة (`GET /ideas` بحالة مكتملة) لتكون مرجعاً للسنوات القادمة وتكريم المشاريع المتميزة (`Outstanding Projects`).

---

### ثالثاً: تدفق المشرف ومساعد التدريس (Supervisor & TA Flow)
1. **لوحة التحكم للمشرف**:
   - عرض طلبات الإشراف المعلقة (`GET /supervisor/ideas/pending/{supervisorId}`).
   - مراجعة الفكرة وأعضاء الفريق ثم القبول أو الرفض -> استدعاء `POST /supervisor/ideas/review`.
2. **إدارة المشاريع التي يشرف عليها**:
   - تصفح المشاريع النشطة التي يتابعها (`GET /supervisor/projects/{supervisorId}`).
   - الدخول لكل مشروع لرؤية نسبة الإنجاز والمهام المسلمة والتعليق عليها.
3. **جدولة الاجتماعات**:
   - إدخال تفاصيل اجتماع جديد (العنوان، الوصف، التاريخ، الوقت، النوع، الرابط/الموقع) -> استدعاء `POST /meetings` لإرسال إشعارات فورية للطلاب.
4. **تقييم ورصد المناقشات الثلاث**:
   - **المناقشة الأولى**: رصد الملاحظات والتعديلات المطلوبة -> استدعاء `POST /supervisor/project/{projectId}/discussion-1`.
   - **المناقشة الثانية**: رصد نسبة الإنجاز ودرجات الطلاب الفردية المبدئية -> استدعاء `POST /supervisor/project/{projectId}/discussion-2`.
   - **المناقشة الثالثة (النهائية)**: رصد الدرجات التفصيلية النهائية (التقرير، العرض، الجانب العملي والتطبيق) -> استدعاء `POST /supervisor/project/{projectId}/discussion-3`.
   - **التمييز الأكاديمي**: إمكانية تمييز المشروع كمشروع ممتاز لعرضه بالمكتبة الرقمية -> `PUT /supervisor/project/{projectId}/outstanding`.

---

## 3. مخططات تدفق التطبيق المنظمة (Mermaid Diagrams)

### أ- مخطط حالات الطالب (Student State Machine Diagram)
يوضح هذا المخطط الحالات الست للطالب وكيفية الانتقال بينها:

```mermaid
stateDiagram-v2
    [*] --> No_Idea : تسجيل الدخول / إنشاء حساب
    
    state No_Idea {
        [*] --> Explore_Marketplace
        Explore_Marketplace --> Send_Join_Request : إرسال طلب انضمام لفكرة
        [*] --> Fill_Create_Idea_Form : تعبئة نموذج فكرة جديدة
    }

    Fill_Create_Idea_Form --> Idea_Owner : إنشاء فكرة بنجاح (POST /ideas)
    Send_Join_Request --> Idea_Member : قبول الطلب من صاحب الفكرة (Accept Join)
    
    state Idea_Owner {
        [*] --> Manage_Requests : إدارة طلبات الانضمام
        Manage_Requests --> Accept_Members : قبول أعضاء حتى اكتمال العدد
        Accept_Members --> Run_AI_Check : اكتمال الفريق (تفعيل زر فحص AI)
        Run_AI_Check --> Select_Supervisor : اجتياز فحص التشابه (Similarity < 30%)
        Select_Supervisor --> Submit_To_Supervisor : إرسال طلب الإشراف
    }
    
    state Idea_Member {
        [*] --> Read_Only_View : عرض تفاصيل الفكرة فقط
        Read_Only_View --> Leave_Team : مغادرة الفريق (POST /leave-team)
    }
    
    Leave_Team --> No_Idea : العودة للبحث عن فريق
    
    Submit_To_Supervisor --> Idea_Under_Review : تقديم الفكرة (Under Review)
    
    state Idea_Under_Review {
        [*] --> Wait_For_Decision : انتظار قرار المشرف الأكاديمي
    }
    
    Idea_Under_Review --> Idea_Owner : رفض المشرف (Rejected) -> تعديل الفكرة/تغيير المشرف
    Idea_Under_Review --> Active_Project : موافقة المشرف (Approved) -> تفعيل المشروع
    
    state Active_Project {
        [*] --> Manage_Tasks : تتبع وإنجاز المهام المسندة
        [*] --> Attend_Meetings : حضور الاجتماعات الأكاديمية
        [*] --> Submit_Discussions : تقييمات المناقشات (1 و 2)
        Submit_Discussions --> Complete_All_Requirements : إتمام كافة المتمتطلبات
    }
    
    Complete_All_Requirements --> Project_Completed : رصد الدرجات النهائية للمناقشة 3 (Discussion 3)
    
    state Project_Completed {
        [*] --> View_Final_Grades : استعراض الدرجات والتفاصيل
        [*] --> Auto_Archived_To_Library : الأرشفة التلقائية في المكتبة الرقمية
    }
    
    Project_Completed --> [*] : التخرج
```

### ب- مخطط التدفق العام للنظام (General System Flowchart)
يوضح التفاعل الشامل بين الطالب، المشرف، ونظام الذكاء الاصطناعي:

```mermaid
flowchart TD
    %% تعريف أنماط التصميم والمظهر
    classDef actorStyle fill:#2A3439,stroke:#1F2421,stroke-width:2px,color:#fff,font-weight:bold;
    classDef systemStyle fill:#004B23,stroke:#38B000,stroke-width:2px,color:#fff;
    classDef processStyle fill:#0077B6,stroke:#0096C7,stroke-width:2px,color:#fff;
    classDef decisionStyle fill:#D90429,stroke:#EF233C,stroke-width:2px,color:#fff;

    %% تعريف العقد الفاعلة
    Student((الطالب)):::actorStyle
    Supervisor((المشرف الأكاديمي)):::actorStyle
    AISystem{{"نظام فحص الذكاء الاصطناعي"}}:::systemStyle
    
    Start([شاشة الدخول / التسجيل]) --> DecisionLogin{هل يمتلك حساب؟}:::decisionStyle
    DecisionLogin -- لا --> Register[إنشاء حساب جديد]:::processStyle
    Register --> Login[تسجيل الدخول JWT Token]:::processStyle
    DecisionLogin -- نعم --> Login
    
    Login --> RoleDecision{تحديد دور المستخدم}:::decisionStyle
    
    %% مسار الطالب
    RoleDecision -- طالب -->  NoIdea[حالة: بدون فكرة]:::processStyle
    NoIdea --> ChoosePath{اختيار المسار}:::decisionStyle
    
    ChoosePath -- انضمام لفكرة --> JoinRequest[تصفح الأفكار وإرسال طلب انضمام]:::processStyle
    JoinRequest --> WaitAccept{هل وافق صاحب الفكرة؟}:::decisionStyle
    WaitAccept -- نعم --> MemberState[حالة: عضو في فكرة]:::processStyle
    WaitAccept -- لا --> NoIdea
    
    ChoosePath -- إنشاء فكرة --> OwnerState[حالة: صاحب فكرة]:::processStyle
    OwnerState --> RecruitMembers[قبول أعضاء الفريق الجدد]:::processStyle
    RecruitMembers --> TeamComplete{هل اكتمل الفريق؟}:::decisionStyle
    TeamComplete -- لا --> RecruitMembers
    TeamComplete -- نعم --> RunCheck[تشغيل فحص التشابه بالذكاء الاصطناعي]:::processStyle
    
    RunCheck --> AISystem
    AISystem --> ScoreDecision{هل نسبة التشابه أقل من 30%؟}:::decisionStyle
    ScoreDecision -- لا --> RejectAI[تعديل عنوان/وصف الفكرة]:::processStyle
    RejectAI --> RunCheck
    ScoreDecision -- نعم --> SelectSup[اختيار المشرف وإرسال الطلب]:::processStyle
    
    SelectSup --> UnderReviewState[حالة: تحت المراجعة]:::processStyle
    UnderReviewState --> SupDecision{قرار المشرف الأكاديمي}:::decisionStyle
    
    %% مسار المشرف
    RoleDecision -- مشرف/معيد --> SupDashboard[لوحة تحكم المشرف]:::processStyle
    SupDashboard --> PendingRequests[عرض طلبات الإشراف المعلقة]:::processStyle
    PendingRequests --> ReviewProposal[مراجعة تفاصيل الفكرة والفريق]:::processStyle
    ReviewProposal --> ApproveRequest[اتخاذ قرار القبول/الرفض]:::processStyle
    ApproveRequest --> SupDecision
    
    SupDecision -- رفض --> OwnerState
    SupDecision -- قبول --> ActiveProject[حالة: مشروع نشط للجميع]:::processStyle
    
    %% مرحلة التنفيذ والمناقشات
    ActiveProject --> ExecutionPhase[مرحلة التنفيذ والمتابعة]:::processStyle
    ExecutionPhase --> TasksManagement[إسناد وتسليم المهام الأكاديمية]:::processStyle
    ExecutionPhase --> MeetingsSched[جدولة وحضور الاجتماعات الدورية]:::processStyle
    
    ExecutionPhase --> Discussion1[المناقشة الأولى: الفكرة والتصميم]:::processStyle
    Discussion1 --> Discussion2[المناقشة الثانية: التقدم والبرمجة]:::processStyle
    Discussion2 --> FinalDiscussion[المناقشة الثالثة والنهائية]:::processStyle
    
    FinalDiscussion --> GradePosting[رصد الدرجات النهائية وإغلاق المشروع]:::processStyle
    GradePosting --> CompletedState[حالة: مشروع مكتمل]:::processStyle
    
    CompletedState --> Archiving[الأرشفة التلقائية في المكتبة الرقمية للمشروع]:::processStyle
    Archiving --> EndState([التخرج بنجاح])
```
